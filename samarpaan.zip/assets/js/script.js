$('document').ready(function(){

toastr.options = {
	  "closeButton": true,
	  "debug": false,
	  "positionClass": "toast-top-right",
	  "onclick": null,
	  "showDuration": "1000",
	  "hideDuration": "1000",
	  "timeOut": "5000",
	  "extendedTimeOut": "1000",
	  "showEasing": "swing",
	  "hideEasing": "linear",
	  "showMethod": "fadeIn",
	  "hideMethod": "fadeOut"
	};

		$('.error-msg').hide();
		$(".login-btn").on('click',function(e){

		e.preventDefault();
		var email    = $('.email').val();
		var password = $('.password').val();
		var action = $('input[name="action"]').val();
		$('.error-msg').hide();
		

		$.ajax({

			url : action,
			type: 'POST',
			data : {email:email,password:password},
			beforeSend :  function(){
				$('.login-loader').show();

			},

			success :function(html) {

				console.log(html);
				
				var data = JSON.parse(html);

				if (data.status=='false') {

					$('.error').html(data.msg);
					$('.error-msg').show();


				} else {

					window.location = ajax_url+'admin';
				}

			}


		});

	});


	$('.create-staff-btn').on('click',function(e){

		e.preventDefault();

		var name     = $('.name').val();
		var mobile   = $('.phone').val();
		var password = $('.password').val();
		var staff_id = $('.staff_id').val();
		var retype   = $('.retype').val();


		$('.name-error').html('');
		$('.phone-error').html('');
		$('.staff_id-error').html('');
		$('.password-error').html('');
		$('.retype-error').html('');

		if (password!=retype) {

			$('.retype-error').html('Password did not matched !');

			return;
		}
				

		$.ajax({

			url : ajax_url+"admin/create",
			
			type: 'POST',
			
			data : {name:name,mobile:mobile,staff_id:staff_id,password:password},
			
			success :function(html) {

				console.log(html);
				

				var data = JSON.parse(html);

				if (data.status=='false') {

					$('.name-error').html(data.name);
					$('.phone-error').html(data.phone);
					$('.staff_id-error').html(data.staff_id);
					$('.password-error').html(data.password);
					toastr['error']('vandor could not be created, please try later !','Error');
					
				} else {
				
					
					toastr['success']('staff created successfully','success');
					
					$('.name').val('');
					$('.phone').val('');
					$('.password').val('');
					$('.staff_id').val('');
					$('.retype').val('');


					
				}
				
			}


		});
	});

	$('button.create_user').on('click',function(e){

		e.preventDefault();

		var btn = $(this);
		var form = btn.closest('form');
		var staff_id = form.find('input[name="staff_id"]').val();
		var name     = form.find('input[name="name"]').val();
		var email    = form.find('input[name="email"]').val();
		var mobile   = form.find('input[name="mobile"]').val();
		var address  = form.find('textarea[name="address"]').val();
		var parent_id  = form.find('input[name="parent_id"]').val();
		
		form.find('.name-error').html('');
		form.find('.phone-error').html('');
		form.find('.staff_id-error').html('');
		form.find('.email-error').html('');
		form.find('.address-error').html('');
	

		$.ajax({

			url : ajax_url+"staff/create_user",
			
			type: 'POST',
			
			data : {staff_id:staff_id,name:name,email:email,mobile:mobile,address:address,parent_id:parent_id},
			beforeSend : function(){

				btn.html('wait...');
			},
			success :function(html) {

				btn.html('submit');
				console.log(html);
				

				var data = JSON.parse(html);

				if (data.status=='false') {

					form.find('.name-error').html(data.name);
					form.find('.mobile-error').html(data.mobile);
					form.find('.staff-error').html(data.staff_id);
					form.find('.email-error').html(data.email);
					form.find('.address-error').html(data.address);
					toastr['error']('user could not be created, please try later !','Error');
					
				} else {
				
					
					toastr['success']('staff created successfully','success');

						form.find('input[name="staff_id"]').attr('disabled','disabled');
						form.find('input[name="name"]').attr('disabled','disabled');
						form.find('input[name="email"]').attr('disabled','disabled');
						form.find('input[name="mobile"]').attr('disabled','disabled');
						form.find('textarea[name="address"]').attr('disabled','disabled');
						btn.attr('disabled','disabled');

						location.reload();
				}
				
			}


		});
	});


	$('.edit-staff-btn').on('click',function(e){

		e.preventDefault();

		var name     = $('.name').val();
		var mobile   = $('.phone').val();
		var id 		 = $(this).attr('data-staffId');
		var staff_id = $('.staff_id').val();



		$('.name-error').html('');
		$('.phone-error').html('');
		$('.staff_id-error').html('');
		
	

		$.ajax({

			url : ajax_url+"admin/edit_staff",
			
			type: 'POST',
			
			data : {name:name,mobile:mobile,staff_id:staff_id,id:id},
			
			success :function(html) {

				console.log(html);
				

				var data = JSON.parse(html);

				if (data.status=='false') {

					$('.name-error').html(data.name);
					$('.phone-error').html(data.phone);
					$('.staff_id-error').html(data.staff_id);
					
					toastr['error']('staff could not be updated, please try later !','Error');
					
				} else {
				
					
					toastr['success']('staff updated successfully','success');
					
					
				


					
				}
				
			}


		});
	});

	$('.delete-staff').on('click',function() {

		var staff_id = $(this).attr('data-staffId');
		var confirm = window.confirm('Are you sure, the staff member will be deleted permanently !');
		var btn = $(this);
		if(confirm){

			$.ajax({

			url  : ajax_url+'admin/delete',
			type : 'POST',
			data : {id:staff_id},
			beforeSend : function() {

				btn.before('<img class="ajax-loader" src="'+ajax_url+'assets/img/ajax-loader.gif">');
			},
			success : function(html) {

				console.log(html);

				$('.ajax-loader').hide();

				if (html=='success') {

					$('#row_'+staff_id).fadeOut();
					toastr['success']('Staff delete !','success')

				} else {

					toastr['error']('Could not delete staff, try later !');


				}
			}
		});

		} 
		

	});


	$('.get_coupon').on('click',function(){

		var user_id = $(this).attr('data-staffId');
		var user1   = $(this).attr('data-userOne');
		var user2   = $(this).attr('data-userTwo');
		var user3   = $(this).attr('data-userThree');
		var coupon   = $(this).attr('data-coupon');
		var btn = $(this);

		$.ajax({

			url : ajax_url+'staff/generate_coupon',
			type : 'post',
			data : {user_id:user_id,user1:user1,user2:user2,user3:user3,coupon:coupon},
			beforeSend : function() {
			
					btn.attr('disabled','disabled');
			
			},
			success  :function(html) {

				if (html=='success') {

					setTimeout(function(){

						$('.coupon-print').print({
							globalStyles: true,
				        	mediaPrint: false,
				        	stylesheet: null,
				        	noPrintSelector: ".no-print",
				        	iframe: true,
				        	append: null,
				        	prepend: null,
				        	manuallyCopyFormValues: true,
				        	deferred: $.Deferred(),
				        	timeout: 750,
				        	title: null,
				        	doctype: '<!doctype html>'
						});
						
					},2000);


						


				}

			}



		});

		return false;


	});

	$('.activate-user').on('click',function(){

		var user_id = $(this).attr('data-userId');
		var phone   = $(this).attr('data-phone');
		var btn = $(this);

		if (user_id=='' || phone=='') {
			toastr['error']('These was an error !, try later');
			return false;
		}

		$.ajax({

			type : 'POST',
			url : ajax_url+'staff/activate_user',
			data : {user_id:user_id},

			beforeSend : function() {

				btn.html('Please wait...');

			},
			success : function(html) {

				btn.html('Activate Account');

				console.log(html);
				if (html=='success') {

					toastr['success']('Successfully activated account !');

					setTimeout(function(){

						window.location = ajax_url+'staff/level_two?search='+phone;
			
					},2000);
				}

			}
		});


	});



});