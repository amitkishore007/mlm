<?php 
defined('BASEPATH') OR exit('No direct script access allowed');


/**
* 
*/
class StaffLogin extends CI_Controller
{
	

	public function __construct() {

		parent::__construct();
		$this->load->model('loginModel');
		$this->load->model('staffLoginModel');
	}

	private function check_login(){

		if ($this->session->userdata('is_logged_in')) {
		
			return redirect('welcome');
		}
	}

	public function index() {

		$this->check_login();


		$data['main_content'] = 'staff/login';

		$this->load->view('includes/template',$data);

	}
	
	public function login() {

		if ($this->input->post()) {

			
			$user = $this->staffLoginModel->login('staff');
			
			echo json_encode($user);

				
		} else {

			return redirect('staffLogin');
		}

	}


	public function logout() {

		$this->check_login();

		$data = array(

			'user_id'     , 
			'user_email'  , 
			'username'    , 
			'role'        , 
			'is_logged_in'
		);

		$this->session->unset_userdata($data);

		return redirect('staffLogin=');
	}
	
}