<?php 
defined('BASEPATH') OR exit('No direct script access allowed');


/**
* admin login
*/
class Admin extends CI_Controller
{
	

	public function __construct() {

		parent::__construct();
		
		if (!$this->session->userdata('is_logged_in')) {
		
			return redirect('adminLogin');
		
		}


		if ($this->session->userdata('user_type') =='staff') {
			
			return redirect('staff');
		}

		
		

		$this->load->model('adminModel');
		$this->load->model('staffModel');

	}


	public function index() {

		 $this->dashboard();		
	}

	public function staff() {

		$data['main_content'] = 'admin/staff_list';
		$data['staff'] = $this->staffModel->staffList();

		$this->load->view('includes/template',$data);

	}


	public function dashboard() {

		$data['main_content'] = 'admin/dashboard';

		$this->load->view('includes/template',$data);
			
	}

	public function logout() {

		$data = array('user_id', 'user_email', 'is_logged_in','user_type' );
		$this->session->unset_userdata($data);
		$this->session->sess_destroy();
		return redirect('app');

	}


		public function add() { 

		$data['main_content'] = 'admin/add_staff';

		$this->load->view('includes/template',$data);

	}

	public function create() {

		if ($this->input->post()) {
				
			$status = $this->staffModel->create();

			echo json_encode($status);

		} else {

			return redirect('staff');
		}

	}

	public function edit($id) {

		if (!isset($id)) {
			
			return redirect('staff');
		} 


		$id = (int) $id;

		$staff = $this->staffModel->findStaff($id);

		if ($staff) {
			
			$data['staff'] = $staff;

			$data['main_content']  = 'admin/edit_staff';
			
			$this->load->view('includes/template',$data);

		} else {

			return redirect('staff');
		}

	}


	public function edit_staff() {

		if ($this->input->post()) {
			

			$output = $this->staffModel->edit_staff();

			echo json_encode($output);

		} else {

			return redirect('staff');
		}
	}


	public function delete() {
		
		if ($this->input->post()) {
			
			$output = $this->staffModel->delete();

			echo $output;

		} else {

			return redirect('staff');
		}
	}





}