<?php 
defined('BASEPATH') OR exit('No direct script access allowed');


/**
* 
*/
class AdminLogin extends CI_Controller
{
	

	public function __construct() {

		parent::__construct();
		$this->load->model('loginModel');
		
	}

	private function check_login(){

		if ($this->session->userdata('is_logged_in')) {
		
			return redirect('welcome');
		}
	}

	public function index() {

		$this->check_login();


		$data['main_content'] = 'admin/login';

		$this->load->view('includes/template',$data);

	}
	
	public function login() {

		if ($this->input->post()) {

			
			$user = $this->loginModel->login('admin');
			
			echo json_encode($user);

				
		} else {

			return redirect('admin');
		}

	}



	public function create_staff() {

		$this->check_login();

		$data['main_content'] = 'admin/add_staff';
		$this->load->view('includes/template',$data);

	}


	public function create_user() {

		if ($this->input->post()) {

			$output = $this->adminModel->create_user();

			echo json_encode($output);
			
		} else {

			return redirect('admin');
		}
	}


	public function logout() {

		$this->check_login();

		$data = array(
			'user_id'     , 
			'user_email'  , 
			'username'    , 
			'user_type'   , 
			'is_logged_in'
		);

		$this->session->unset_userdata($data);

		return redirect('shop');
	}
	
}