<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

/**
* 
*/
class Staff extends CI_Controller
{

	public function __construct() {

		parent::__construct();
		
		if (!$this->session->userdata('is_logged_in') || $this->session->userdata('user_type') !='staff') {
		
			return redirect('staffLogin');
		
		}


		if ($this->session->userdata('user_type') =='admin') {
			
			return redirect('admin');
		}
		
		$this->load->model('staffModel');
	
	}
	
	
	public function index() {

		$data['main_content'] = 'staff/level_one_reg';
		$data['total_registration'] = $this->staffModel->getTotalReg();
		$users = $this->staffModel->get_all_reg_users();

		if(isset($users)):
			$array = array();
			foreach ($users as $user) {
				$array[] = array('id'=>$user->id,'name'=>$user->name,'mobile'=>$user->mobile,'email'=>$user->email,'address'=>$user->address);
			}

			$data['users']  = $array;
		endif;

		$this->load->view('includes/template',$data);

	}

	public function level_one() {

		$this->index();

	}
	
	public function level_two() {

		$data['main_content'] = 'staff/level_two_reg';
		
		if ($this->input->get('search')) {
			
			$user = $this->staffModel->get_user();


		if($user):
			$data['curr_user'] = $user; 

			$users = $this->staffModel->get_all_sub_users($user->id);
			$data['users'] = $users;

			if (count($users)==3) {
				
				$data['coupon_status'] = $this->staffModel->coupon_status($user,$users[0]['id'],$users[1]['id'],$users[2]['id']);

			}
			endif;

			$this->load->helper('string');
			$data['coupon']  = 'PETROL-'.random_string('alnum',5);

		

		}
		$this->load->view('includes/template',$data);

	}
	public function logout() {

		$data = array('user_id', 'user_email', 'is_logged_in','user_type' );
		$this->session->unset_userdata($data);
		$this->session->sess_destroy();
		return redirect('app');

	}

	public function create_user() {

		if ($this->input->post()) {
			
			$output = $this->staffModel->create_user();

			echo json_encode($output);	

		} else  {

			return redirect('staff');
		}
	}


	public function generate_coupon() {

		if ($this->input->post()) {
				
			$output = $this->staffModel->generate_coupon();

			echo $output;

		} else {

			return redirect('staff');
		}

	}


	public function activate_user() {

		if ($this->input->post()) {
		
			$output = $this->staffModel->activate_user();

			echo $output;

		} else {

			return redirect('staff');
		}
	}


	
}