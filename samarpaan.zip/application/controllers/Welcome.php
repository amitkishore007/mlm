<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	
	public function __construct() {

		parent::__construct();
		
		if (!$this->session->userdata('is_logged_in')) {
		
			return redirect('app');
		
		}

		if ($this->session->userdata('user_type')=='staff') {
				
				return redirect('staff');
			}

	}


	public function index()
	{
	
		$data['main_content'] = 'admin/dashboard';
		$this->load->view('includes/template',$data);
	}

	public function logout() {

		$data = array('user_id', 'user_email', 'is_logged_in','user_type' );
		$this->session->unset_userdata($data);
		$this->session->sess_destroy();
		return redirect('app');

	}
}
