<?php 



/**
* 
*/
class App extends CI_Controller
{
	
	public function __construct() {

		parent::__construct();

		if ($this->session->userdata('is_logged_in')) {
			
			if ($this->session->userdata('user_type')=='staff') {
				
				return redirect('staff');
			}

			if ($this->session->userdata('user_type')=='admin') {
				
				return redirect('admin');
			}
		}
	}



	public function index() {

		$data['main_content'] = 'admin/home';

		$this->load->view('includes/template',$data);



	}	




}