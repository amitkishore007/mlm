<?php 


$config =  [

	'login_form_validation'=>[

							[
							'field' => 'email',
							'label' => 'Email',
							'rules' => 'required|valid_email'
        
							],
							[
							
							'field' => 'password',
							'label' => 'Password',
							'rules' => 'required'
        
							]
		

	],
	'staff_login_form_validation'=>[

							[
							'field' => 'email',
							'label' => 'Staff id',
							'rules' => 'required'
        
							],
							[
							
							'field' => 'password',
							'label' => 'Password',
							'rules' => 'required'
        
							]
		

	],

	'staff_form_validation' =>[

						[
						'field' => 'name',
						'label' => 'Staff name',
						'rules' => 'required|min_length[3]'
    
						],
						[
						'field' => 'mobile',
						'label' => 'Phone number',
						'rules' => 'required|exact_length[10]|is_unique[users.email]'
    
						],
						[
						
						'field' => 'password',
						'label' => 'Password',
						'rules' => 'required|min_length[5]'
    
						],
						[
						
						'field' => 'staff_id',
						'label' => 'staff id',
						'rules' => 'required|is_unique[users.staff_id]|alpha_numeric'
    
						]



	],

	'staff_edit_form_validation' =>[

						[
						'field' => 'name',
						'label' => 'Staff name',
						'rules' => 'required|min_length[3]'
    
						],
						[
						'field' => 'mobile',
						'label' => 'Phone number',
						'rules' => 'required|exact_length[10]|is_unique[users.email]'
    
						],
						[
						
						'field' => 'staff_id',
						'label' => 'staff id',
						'rules' => 'required|is_unique[users.staff_id]|alpha_numeric'
    
						]



	],
	'user_create_form_validation' =>[

						[
						'field' => 'name',
						'label' => 'Staff name',
						'rules' => 'required|min_length[3]'
    
						],
						[
						'field' => 'mobile',
						'label' => 'Phone number',
						'rules' => 'required|exact_length[10]|is_unique[users.mobile]'
    
						],
						[
						
						'field' => 'staff_id',
						'label' => 'staff id',
						'rules' => 'required|alpha_numeric'
    
						],
						[
						
						'field' => 'email',
						'label' => 'Email address',
						'rules' => 'required|is_unique[users.email]'
    
						],

						[
						
						'field' => 'address',
						'label' => 'Address',
						'rules' => 'required'
    
						],




	],

	

];