	<div class="container-fluid">
  <div class="row">
    <div class="col-lg-12 col-md-offset-4">
      <div class="admin">Staff</div>
    </div>
      
    </div>
  </div>

	
    <div class="container-fluid">
  <div class="row">
    <div class="col-lg-3 col-md-3">
      <?php $this->load->view('admin_includes/menu'); ?>
    </div>
	<div class="col-lg-6 col-md-6">
      <div class="Registration-form">
 
 <form class="form-horizontal">
  <div class="form-group">
    <label for="inputName" class="col-sm-2 control-label">Name</label>
    <div class="col-sm-10">
      <input type="text" class="form-control name" value='<?php echo $staff->name; ?>' placeholder="Name">
   <span class="text-danger name-error"></span>
    </div>
  </div>
  <div class="form-group">
    <label for="inputMobile" class="col-sm-2 control-label">Mobile No.</label>
    <div class="col-sm-10">
      <input type="number" class="form-control phone" value='<?php echo $staff->mobile; ?>' placeholder="Mobile No.">
   <span class="text-danger phone-error"></span>
    </div>
  </div>
  
  
  <div class="form-group">
    <label for="Staff Id" class="col-sm-2 control-label">Staff Id</label>
    <div class="col-sm-10">
      <input type="text" class="form-control staff_id" value='<?php echo $staff->staff_id; ?>'  placeholder="Staff Id">
      <span class="text-danger staff_id-error "></span>
    </div>
  </div>
  
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" data-staffId='<?php echo $staff->id; ?>' class="btn btn-default edit-staff-btn">Submit</button>
    </div>
  </div>
</form>
 </div>
    </div>
      
    </div>
  </div>
	
	