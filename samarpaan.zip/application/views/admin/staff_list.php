<div class="container-fluid">
  <div class="row">
    <div class="col-lg-12 col-md-offset-4">
      <div class="admin">Staff</div>
    </div>
      
    </div>
  </div>

	
<div class="container-fluid">
  <div class="row">
    <div class="col-lg-3 col-md-3">
     <?php $this->load->view('admin_includes/menu'); ?>
    </div>
	<div class="col-lg-6 col-md-6">
      <div class="panel panel-default">
        <!-- Default panel contents -->
        <div class="panel-heading">View Staff</div>
        <!-- Table -->
        <table class="table" style="border:1px solid" >
          <thead>
            <tr>
              <th style="border:1px solid" >Staff Id</th>
              <th style="border:1px solid" >Name</th>
              <th style="border:1px solid" >Mobile number</th>
              <th style="border:1px solid" >Action</th>
            </tr>
          </thead>
          <tbody>
          <?php if(isset($staff)): ?>
            <?php foreach($staff as $member): ?>
            <tr id='row_<?php echo $member->id; ?>'>
              <th style="border:1px solid" ><?php echo $member->staff_id; ?></th>
              <td style="border:1px solid" ><?php echo ucwords($member->name); ?></td>
              <td style="border:1px solid" ><?php echo $member->mobile; ?></td>
              <td style="border:1px solid" >
                <a href="javascript:void(0);" class= 'delete-staff btn btn-danger btn-xs' data-staffId='<?php echo $member->id; ?>'> Delete</a>

                <a href="<?php echo base_url('admin/edit/'.$member->id); ?>" class='btn btn-primary btn-xs' > Edit</a>
                

              </td>
            </tr>
          <?php endforeach; ?>
          <?php else: ?>

            <tr><p>No Staff found</p></tr>
          <?php endif; ?>
            
          </tbody>
        </table>
      </div>
    </div>
      
    </div>
  </div>
	