<div class="container-fluid">
  <div class="row">
    <div class="col-lg-12 col-md-offset-4">
      <div class="admin"><a href="#">Admin</a></div>
    </div>
    <div class="col-lg-12 col-md-12">
      <h1 class="create-staff"> Staff</h1>
     
     <ul>
     <li><?php echo anchor('admin/staff','View staff') ?></li> 
     <li><?php echo anchor('admin/add','Add staff') ?></li> 
     
     
	 </ul>
	 
    </div>
	  <div class="col-lg-12 col-md-12">
      <h1 class="create-staff">Cash Status</h1>
      <ul>
  	    <li><a href="javascript:void(0);">View Cash Status</a></li>
        <li><a href="javascript:void(0);">By Staff</a></li>
       
        <li><a href="javascript:void(0);">Total Cash</a></li>
  	  
        <li><a href="javascript:void(0);">Refund</a></li>
  	    <li><a href="javascript:void(0);">Coupon Issued</a></li>
  	 </ul>
	 
    </div>
	
	<div class="col-lg-12 col-md-12">
      <h1 class="create-staff">Petrol Pump Status</h1>
     
     <ul>
	    <li><a href="<?php echo base_url('pump'); ?>">View Pump Status</a></li>
      <li><a href="<?php echo base_url('pump/add'); ?>">Add Petrol Pump</a></li>
	   </ul>
	 
    </div>
      <div class="col-lg-12 col-md-12">
      <h1 class="create-staff">Menu</h1>
     
     <ul>
      <li><a href="<?php echo base_url('welcome/logout'); ?>">Logout</a></li>
     
     </ul>
   
    </div>
  </div>
</div>