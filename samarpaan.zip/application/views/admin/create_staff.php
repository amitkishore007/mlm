 <div class="container-fluid">
         <div class="row">
             <div class="col-lg-12 col-md-offset-4">
                  <div class="admin"><a href="log-in.html">Admin</a></div>
             </div>
             <div class="col-lg-12 col-md-offset-4">
                  <div class="admin"><a href="login-staff.html">Staff</a></div>
             </div>
         </div>
    </div>