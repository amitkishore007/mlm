	<div class="container-fluid">
  <div class="row">
    <div class="col-lg-12 col-md-offset-4">
      <div class="admin">Staff</div>
    </div>
      
    </div>
  </div>

	
    <div class="container-fluid">
  <div class="row">
    <div class="col-lg-3 col-md-3">
      <?php $this->load->view('admin_includes/menu'); ?>
    </div>
	<div class="col-lg-6 col-md-6">
      <div class="Registration-form">
 
 <form class="form-horizontal">
  <div class="form-group">
    <label for="inputName" class="col-sm-2 control-label">Name</label>
    <div class="col-sm-10">
      <input type="text" class="form-control name"  placeholder="Name">
   <span class="text-danger name-error"></span>
    </div>
  </div>
  <div class="form-group">
    <label for="inputMobile" class="col-sm-2 control-label">Mobile No.</label>
    <div class="col-sm-10">
      <input type="number" class="form-control phone"  placeholder="Mobile No.">
   <span class="text-danger phone-error"></span>
    </div>
  </div>
  
  
  <div class="form-group">
    <label for="Staff Id" class="col-sm-2 control-label">Staff Id</label>
    <div class="col-sm-10">
      <input type="text" class="form-control staff_id"  placeholder="Staff Id">
      <span class="text-danger staff_id-error "></span>
    </div>
  </div>
  <div class="form-group">
    <label for="password" class="col-sm-2 control-label">Password</label>
    <div class="col-sm-10">
      <input type="Password" class="form-control password"  placeholder="Password" id='password'>
      <span class="text-danger password-error"></span>
    </div>
  </div>
  <div class="form-group">
    <label for="retype" class="col-sm-2 control-label">Retype password</label>
    <div class="col-sm-10">
      <input type="Password" id='retype' class="form-control retype"  placeholder="Retype Password">
      <span class="text-danger retype-error"></span>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default create-staff-btn">Submit</button>
    </div>
  </div>
</form>
 </div>
    </div>
      
    </div>
  </div>
	
	