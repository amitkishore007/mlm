 <div class="container-fluid">
         <div class="row">
             <div class="col-lg-12 col-md-offset-4">
                  <div class="admin"><?php echo anchor('admin','Admin'); ?></div>
             </div>
             <div class="col-lg-12 col-md-offset-4">
                  <div class="admin"><?php echo anchor('staffLogin','Staff') ?></div>
             </div>
         </div>
    </div>