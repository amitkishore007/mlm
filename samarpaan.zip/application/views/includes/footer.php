  
   <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <!-- <script src="js/bootstrap.min.js"></script> -->
    <script src='<?php echo base_url('assets/js/bootstrap.js'); ?>'></script>
    <script src='//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js'></script>
    <script src='<?php echo base_url('assets/js/jQuery.print.js'); ?>'></script>
    
    <script type="text/javascript">
    	var ajax_url = "<?php echo base_url(); ?>";
    </script>
    <script type="text/javascript" src='<?php echo base_url('assets/js/script.js'); ?>'></script>
  </body>
</html>