<!DOCTYPE html>
<html lang="en">


<head>
    <!-- Meta information -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><!-- Mobile Specific Metas -->
    
    <!-- Title -->
    <title>Petrol</title>
    
   
    <!-- CSS Stylesheet -->
   <!-- bootstrap css -->
    <?php echo link_tag('assets/css/bootstrap.css','stylesheet'); ?> 
    
    <!-- font css -->
    <?php echo link_tag('assets/css/style.css','stylesheet'); ?> 
   <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
   
    

</head>
    
<body>