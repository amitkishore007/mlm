<div class="container-fluid">
    <div class="row">
    <div class="col-lg-12 col-md-12">
  <div class="admin" style='display:inline-block;'><a href="#">welcome: <?php echo $this->session->userdata('user_name') ? $this->session->userdata('user_name') : 'staff';  ?></a> </div>
  <div class="admin" style='display:inline-block;'><a href="<?php echo base_url('staff/logout'); ?>">Logout</a> </div>
        </div>
		 
		 
        </div>
    
    </div>
    <?php //print_r($curr_user); ?>
	
	<div class="container-fluid">
    <div class="row">
    <div class="col-lg-12 col-md-12">
	<div class="search-form">
  <form class="form-inline" >
  <div class="form-group">
    
    <input type="text" class="form-control"  placeholder="Search">
  </div>
  <div class="form-group" style="margin: 0px 70px;">
    <a  href='<?php echo base_url('staff'); ?>' class="btn btn-default">Level 1</a>
  </div>
  
  <a class="btn btn-default" href='<?php echo base_url('staff/level_two'); ?>'>Level 2</a>
  </form>
        </div>
		 
		 </div>
        </div>
    
    </div>
	<div class="container-fluid">
    
      <div class="reg-two">
        <div class="row">
        
          <div class="search-div">
            <div class="col-md-6 col-md-offset-3">
               
                  <form action="" autocomplete="off" class="form-horizontal" method="get" accept-charset="utf-8">
                      <div class="input-group">
                          <input name="search" required pattern='[0-9]{10}' title="10 digit mobile number required" class="form-control" type="text" placeholder="search user by phone number" value='<?php echo isset($curr_user) ? $curr_user->mobile : ''; ?>'>
                          <span class="input-group-btn">
                             <button class="btn btn-default" type="submit"  id="search-user-btn">Search
                             </button>
                          </span>
                      </div>
                  </form>
               
            </div>
           <?php if(isset($curr_user)): ?>
            <div class="col-md-6 col-md-offset-3">
              <div class="user-info">
                <p class="text-center"><b>Name: </b> <?php echo ucwords($curr_user->name); ?> <br/><b>Mobile:</b> <?php echo $curr_user->mobile; ?><br/> <b>Email:</b> <?php echo $curr_user->email; ?>  </p>
                
              </div>
            </div>
          <?php endif; ?>

          </div>
    <?php if(isset($curr_user) && $curr_user->account_status==1): ?>
        <div class="user-register-section">
              <div class="col-md-12">
                     <h1 class='text-center clearfix'>Register</h1>
                
              </div>
                   
              <div class="col-lg-4 col-md-4">
              <div class="Registration-form">
             
             <form class="form-horizontal">
              <div class="form-group">
                <label for="inputName" class="col-sm-2 control-label">Name</label>
                <div class="col-sm-10">
                 <?php if(isset($coupon_status) && $coupon_status): ?>
                  <input type="text" class="form-control" name='name' placeholder="Name" value='' >
                 <?php else: ?>
                  <input type="text" class="form-control" name='name' placeholder="Name" value='<?php echo (isset($users[0]) && !empty($users[0])) ? $users[0]['name'] : ''; ?>' <?php echo (isset($users[0]) && !empty($users[0])) ? 'disabled readonly' : ''; ?>>
                 <?php endif; ?>
                 <span class="error text-danger name-error"></span>
                </div>
              </div>
              <div class="form-group">
                <label for="inputMobile" class="col-sm-2 control-label">Mobile No.</label>
                <div class="col-sm-10">
                  
                  <?php if(isset($coupon_status) && $coupon_status): ?>
                  <input type="number" class="form-control" name='mobile' placeholder="Mobile No." value='' >
                  
                  <?php else: ?>
                  <input type="number" class="form-control" name='mobile' placeholder="Mobile No." value='<?php echo (isset($users[0]) && !empty($users[0])) ? $users[0]['mobile'] : ''; ?>' <?php echo (isset($users[0]) && !empty($users[0])) ? 'disabled readonly' : ''; ?>>
                  
                  <?php endif; ?>
                 
                 <span class="error text-danger mobile-error"></span>
                </div>
              </div>
              <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
                <div class="col-sm-10">
                
                  <?php if(isset($coupon_status) && $coupon_status): ?>
                   <input type="email" class="form-control" name='email' id="inputEmail3" placeholder="Email" value='' >
                  
                  <?php else: ?>
                  
                   <input type="email" class="form-control" name='email' id="inputEmail3" placeholder="Email" value='<?php echo (isset($users[0]) && !empty($users[0])) ? $users[0]['email'] : ''; ?>' <?php echo (isset($users[0]) && !empty($users[0])) ? 'disabled readonly' : ''; ?>>
                  <?php endif; ?>
                
                 <span class="error text-danger email-error"></span>
                </div>
              </div>
              <div class="form-group">
                <label for="Address" class="col-sm-2 control-label">Address</label>
                <div class="col-sm-10">
                 
                  <?php if(isset($coupon_status) && $coupon_status): ?>
                  
                  <textarea class="form-control" rows="3" name='address' placeholder="Address" ></textarea>
                  <?php else: ?>
                  
                      <textarea class="form-control" rows="3" name='address' placeholder="Address" <?php echo (isset($users[0]) && !empty($users[0])) ? 'disabled readonly' : ''; ?>><?php echo (isset($users[0]) && !empty($users[0])) ? $users[0]['name'] : ''; ?></textarea>
                  <?php endif; ?>
                 
                 <span class="error text-danger address-error"></span>
                </div>
              </div>
              <div class="form-group">
                <label for="Staff Id" class="col-sm-2 control-label">Staff Id</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name='staff_id' placeholder="Staff Id" value='<?php echo $this->session->userdata('user_staff_id'); ?>' <?php echo (isset($users[0]) && !empty($users[0])) ? 'disabled readonly' : ''; ?> disabled readonly>
                 <span class="error text-danger staff-error"></span>
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                <input type="hidden" name='parent_id' class="parent_id" value='<?php echo $curr_user->id; ?>'>
                
                  <?php if(isset($coupon_status) && $coupon_status): ?>
                  
                  <button type="submit" class="btn btn-default create_user" >Submit</button>
                  <?php else: ?>
                  <button type="submit" class="btn btn-default create_user" <?php echo (isset($users[0]) && !empty($users[0])) ? 'disabled readonly' : ''; ?>>Submit</button>
                  
                  <?php endif; ?>
                
                </div>
              </div>
            </form>
             </div>
                    </div>
                 <div class="col-lg-4 col-md-4">
             <div class="Registration-form">
             
             <form class="form-horizontal">
              <div class="form-group">
                <label for="inputName" class="col-sm-2 control-label">Name</label>
                <div class="col-sm-10">
                
                  <?php if(isset($coupon_status) && $coupon_status): ?>
                  
                  <input type="text" class="form-control" name='name' placeholder="Name" value='' >
                  <?php else: ?>
                  <input type="text" class="form-control" name='name' placeholder="Name" value='<?php echo (isset($users[1]) && !empty($users[1])) ? $users[1]['name'] : ''; ?>' <?php echo (isset($users[1]) && !empty($users[1])) ? 'disabled readonly' : ''; ?>>
                  
                  <?php endif; ?>
                
                 <span class="error text-danger name-error"></span>
                </div>
              </div>
              <div class="form-group">
                <label for="inputMobile" class="col-sm-2 control-label">Mobile No.</label>
                <div class="col-sm-10">
                
                  <?php if(isset($coupon_status) && $coupon_status): ?>
                  
                  <input type="number" class="form-control" name='mobile' placeholder="Mobile No." value='' >
                  <?php else: ?>
                  <input type="number" class="form-control" name='mobile' placeholder="Mobile No." value='<?php echo (isset($users[1]) && !empty($users[1])) ? $users[1]['mobile'] : ''; ?>' <?php echo (isset($users[1]) && !empty($users[1])) ? 'disabled readonly' : ''; ?>>
                  
                  <?php endif; ?>
                
                 <span class="error text-danger mobile-error"></span>
                </div>
              </div>
              <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
                <div class="col-sm-10">
                
                  <?php if(isset($coupon_status) && $coupon_status): ?>
                  <input type="email" class="form-control" name='email' id="inputEmail3" placeholder="Email" value='' >
                  
                  <?php else: ?>
                  <input type="email" class="form-control" name='email' id="inputEmail3" placeholder="Email" value='<?php echo (isset($users[1]) && !empty($users[1])) ? $users[1]['email'] : ''; ?>' <?php echo (isset($users[1]) && !empty($users[1])) ? 'disabled readonly' : ''; ?>>
                  
                  <?php endif; ?>
                
                 <span class="error text-danger email-error"></span>
                </div>
              </div>
              <div class="form-group">
                <label for="Address" class="col-sm-2 control-label">Address</label>
                <div class="col-sm-10">
                
                  <?php if(isset($coupon_status) && $coupon_status): ?>
                  
                 <textarea class="form-control" rows="3" name='address' placeholder="Address" ></textarea>
                  <?php else: ?>
                 <textarea class="form-control" rows="3" name='address' placeholder="Address" <?php echo (isset($users[1]) && !empty($users[1])) ? 'disabled readonly' : ''; ?>><?php echo (isset($users[1]) && !empty($users[1])) ? $users[1]['name'] : ''; ?></textarea>
                  
                  <?php endif; ?>
                
                 <span class="error text-danger address-error"></span>
                </div>
              </div>
              <div class="form-group">
                <label for="Staff Id" class="col-sm-2 control-label">Staff Id</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name='staff_id' placeholder="Staff Id" value="<?php echo $this->session->userdata('user_staff_id'); ?>" <?php echo (isset($users[1]) && !empty($users[1])) ? 'disabled readonly' : ''; ?> disabled readonly>
                 <span class="error text-danger staff-error"></span>
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                <input type="hidden" name='parent_id' class="parent_id" value='<?php echo $curr_user->id; ?>'>
               
                  <?php if(isset($coupon_status) && $coupon_status): ?>
                  
                  <button type="submit" class="btn btn-default create_user" >Submit</button>
                  <?php else: ?>
                  <button type="submit" class="btn btn-default create_user" <?php echo (isset($users[1]) && !empty($users[1])) ? 'disabled readonly' : ''; ?>>Submit</button>
                  
                  <?php endif; ?>
               
                </div>
              </div>
            </form>
             </div>
                    </div>
                 <div class="col-lg-4 col-md-4">
             <div class="Registration-form print">

             <form class="form-horizontal">
              <div class="form-group">
                <label for="inputName" class="col-sm-2 control-label">Name</label>
                <div class="col-sm-10">
                
                  <?php if(isset($coupon_status) && $coupon_status): ?>
                  
                  <input type="text" class="form-control" name='name' placeholder="Name" value='' >
                  <?php else: ?>
                  <input type="text" class="form-control" name='name' placeholder="Name" value='<?php echo (isset($users[2]) && !empty($users[2])) ? $users[2]['name'] : ''; ?>' <?php echo (isset($users[2]) && !empty($users[2])) ? 'disabled readonly' : ''; ?>>
                  
                  <?php endif; ?>
                
                 <span class="error text-danger name-error"></span>
                </div>
              </div>
              <div class="form-group">
                <label for="inputMobile" class="col-sm-2 control-label">Mobile No.</label>
                <div class="col-sm-10">
                 
                  <?php if(isset($coupon_status) && $coupon_status): ?>
                  <input type="number" class="form-control" name='mobile' placeholder="Mobile No." value='' >
                  
                  <?php else: ?>
                  <input type="number" class="form-control" name='mobile' placeholder="Mobile No." value='<?php echo (isset($users[2]) && !empty($users[2])) ? $users[2]['mobile'] : ''; ?>' <?php echo (isset($users[2]) && !empty($users[2])) ? 'disabled readonly' : ''; ?>>
                  
                  <?php endif; ?>
                 
                 <span class="error text-danger mobile-error"></span>
                </div>
              </div>
              <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
                <div class="col-sm-10">
                 
                  <?php if(isset($coupon_status) && $coupon_status): ?>
                  
                  <input type="email" class="form-control" name='email' id="inputEmail3" placeholder="Email" value='' >
                  <?php else: ?>
                  <input type="email" class="form-control" name='email' id="inputEmail3" placeholder="Email" value='<?php echo (isset($users[2]) && !empty($users[2])) ? $users[2]['email'] : ''; ?>' <?php echo (isset($users[2]) && !empty($users[2])) ? 'disabled readonly' : ''; ?>>
                  
                  <?php endif; ?>
                 
                 <span class="error text-danger email-error"></span>
                </div>
              </div>
              <div class="form-group">
                <label for="Address" class="col-sm-2 control-label">Address</label>
                <div class="col-sm-10">
                
                  <?php if(isset($coupon_status) && $coupon_status): ?>
                 <textarea class="form-control" rows="3" name='address' placeholder="Address" ></textarea>
                  
                  <?php else: ?>
                 <textarea class="form-control" rows="3" name='address' placeholder="Address" <?php echo (isset($users[2]) && !empty($users[2])) ? 'disabled readonly' : ''; ?>><?php echo (isset($users[2]) && !empty($users[2])) ? $users[2]['address'] : ''; ?></textarea>
                  
                  <?php endif; ?>
                
                 <span class="error text-danger address-error"></span>
                </div>
              </div>
              <div class="form-group">
                <label for="Staff Id" class="col-sm-2 control-label">Staff Id</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name='staff_id' placeholder="Staff Id" value='<?php echo $this->session->userdata('user_staff_id'); ?>' disabled readonly>
                 <span class="error text-danger staff-error"></span>
                
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                <input type="hidden" name='parent_id' class="parent_id" value='<?php echo $curr_user->id; ?>'>
                  <button type="submit" class="btn btn-default create_user" <?php echo (isset($users[2]) && !empty($users[2])) ? 'disabled readonly' : ''; ?>>Submit</button>
                </div>
              </div>
            </form>
             </div>
                    </div>

                 <?php if((count($users)==3  || isset($coupon_status)) && !$coupon_status): ?> 
                    <div class="coupon-div">
                    <div class="row">
                    
                    <div class="col-lg-12 col-md-12">
                         <div class='coupon-print'>
                         <h4>Petrol Coupon</h4>
                         <p class='sub-heading'>SNPL</p>
                            <p><b>Name: </b>
                            <?php echo ucwords($curr_user->name); ?></p>
                            <p><b>Mobile: </b>
                            <?php echo ucwords($curr_user->mobile); ?></p>
                           
                            <p><b>Staff id: </b>
                            <?php echo $this->session->userdata('user_staff_id'); ?></p>
                            <p><b>Petrol Pump: </b>

                            <span class="petrol">
                                Metropole Service Station,<br/>A-23, A44, Cannaught place<br/>New Delhi
                            </span>

                            </p><br/>
                            <div class="clearfix"></div>
                           <p><span class="first"><b>Quantity: </b></span>
                            5 Ltr</p>
                            <p><b>Coupon code: </b>
                            <?php echo $coupon; ?></p>

                          </div>
                    <button type="button" data-staffId='<?php echo $curr_user->id; ?>' data-coupon='<?php echo isset($coupon) ? $coupon :''; ?>' class="btn btn-primary btn-lg btn-block get_coupon" data-userOne='<?php echo (isset($users[0]) && !empty($users[0])) ? $users[0]['id'] : ''; ?>' data-userTwo='<?php echo (isset($users[1]) && !empty($users[1])) ? $users[1]['id'] : ''; ?>' data-userThree='<?php echo (isset($users[2]) && !empty($users[2])) ? $users[2]['id'] : ''; ?>'><a href="javascript:void(0);" >Get A Coupan</a></button>
                    </div>
                    </div>
                    </div>
                  <?php endif; ?>
                  </div><!-- user register seciton-->
              <?php else: ?>
                 <div class="col-md-12 ">
                    <h3 class="text-danger text-center">Your account is not active</h3>
                    <p class="text-center"><a href="javascript:void(0);" data-userId='<?php echo $curr_user->id; ?>' data-phone='<?php echo $_GET['search']; ?>' class='btn btn-primary btn-sm activate-user' >Active account</a></p>
                </div>

              <?php endif; ?>
               
        </div>
      </div>


</div>
	