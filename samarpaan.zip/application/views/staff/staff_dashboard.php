<div class="container-fluid">
    <div class="row">
    <div class="col-lg-12 col-md-12">
  <div class="admin" style='display:inline-block;'><a href="#">welcome: <?php echo $this->session->userdata('user_name') ? $this->session->userdata('user_name') : 'staff';  ?></a> </div>
  <div class="admin" style='display:inline-block;'><a href="<?php echo base_url('staff/logout'); ?>">Logout</a> </div>
        </div>
		 
		 
        </div>
    
    </div>
	
	<div class="container-fluid">
    <div class="row">
    <div class="col-lg-12 col-md-12">
	<div class="search-form">
  <form class="form-inline" >
  <div class="form-group">
    
    <input type="text" class="form-control"  placeholder="Search">
  </div>
  <div class="form-group" style="margin: 0px 70px;">
    <button type="submit" class="btn btn-default">Level 1</button>
  </div>
  
  <button type="submit" class="btn btn-default">Level 2</button>
  </form>
        </div>
		 
		 </div>
        </div>
    
    </div>
	<div class="container-fluid">
    <?php if(isset($total_registration) && $total_registration==0): ?>
        <div class="reg-first">
        <div class="row">
        <div class="col-lg-4 col-md-4">
      <div class="Registration-left">Registration</div>
            </div>
    		 <div class="col-lg-8 col-md-8">
     <div class="Registration-form">
     
     <form class="form-horizontal" id='create_user_form'>
      <div class="form-group">
        <label for="inputName" class="col-sm-2 control-label">Name</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name='name' placeholder="Name">
          <span class="error text-danger name-error"></span>
        </div>
      </div>
      <div class="form-group">
        <label for="inputMobile" class="col-sm-2 control-label">Mobile No.</label>
        <div class="col-sm-10">
          <input type="number" class="form-control" name='mobile' placeholder="Mobile No.">
          <span class="error text-danger mobile-error"></span>
        </div>
      </div>
      <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
        <div class="col-sm-10">
          <input type="email" class="form-control" name='email' id="inputEmail3" placeholder="Email">
          <span class="error text-danger email-error"></span>
        </div>
      </div>
      <div class="form-group">
        <label for="Address" class="col-sm-2 control-label">Address</label>
        <div class="col-sm-10">
         <textarea class="form-control" rows="3" name='address' placeholder="Address"></textarea>
          <span class="error text-danger address-error"></span>
        </div>
      </div>
      <div class="form-group">
        <label for="Staff Id" class="col-sm-2 control-label">Staff Id</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name='staff_id' readonly disabled placeholder="Staff Id" value='<?php echo $this->session->userdata('user_staff_id'); ?>'>
          <span class="error text-danger staff-error"></span>
        </div>
      </div>
      <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
          <button type="submit" class="btn btn-default create_user" id=''>Submit</button>
        </div>
      </div>
    </form>
     </div>
      </div>
    </div>
    </div>
  <?php else: ?>
      
      <div class="reg-two">
        <div class="row">
         <h1 class='text-center'>Register three more</h1>
    <div class="col-lg-4 col-md-4">
  <div class="Registration-form">
 
 <form class="form-horizontal">
  <div class="form-group">
    <label for="inputName" class="col-sm-2 control-label">Name</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name='name' placeholder="Name" value='<?php echo (isset($users[1]) && !empty($users[1])) ? $users[1]['name'] : ''; ?>' <?php echo (isset($users[1]) && !empty($users[1])) ? 'disabled readonly' : ''; ?>>
     <span class="error text-danger name-error"></span>
    </div>
  </div>
  <div class="form-group">
    <label for="inputMobile" class="col-sm-2 control-label">Mobile No.</label>
    <div class="col-sm-10">
      <input type="number" class="form-control" name='mobile' placeholder="Mobile No." value='<?php echo (isset($users[1]) && !empty($users[1])) ? $users[1]['mobile'] : ''; ?>' <?php echo (isset($users[1]) && !empty($users[1])) ? 'disabled readonly' : ''; ?>>
     <span class="error text-danger mobile-error"></span>
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
    <div class="col-sm-10">
      <input type="email" class="form-control" name='email' id="inputEmail3" placeholder="Email" value='<?php echo (isset($users[1]) && !empty($users[1])) ? $users[1]['email'] : ''; ?>' <?php echo (isset($users[1]) && !empty($users[1])) ? 'disabled readonly' : ''; ?>>
     <span class="error text-danger email-error"></span>
    </div>
  </div>
  <div class="form-group">
    <label for="Address" class="col-sm-2 control-label">Address</label>
    <div class="col-sm-10">
     <textarea class="form-control" rows="3" name='address' placeholder="Address" <?php echo (isset($users[1]) && !empty($users[1])) ? 'disabled readonly' : ''; ?>><?php echo (isset($users[1]) && !empty($users[1])) ? $users[1]['name'] : ''; ?></textarea>
     <span class="error text-danger address-error"></span>
    </div>
  </div>
  <div class="form-group">
    <label for="Staff Id" class="col-sm-2 control-label">Staff Id</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name='staff_id' placeholder="Staff Id" value='<?php echo $this->session->userdata('user_staff_id'); ?>' <?php echo (isset($users[1]) && !empty($users[1])) ? 'disabled readonly' : ''; ?> disabled readonly>
     <span class="error text-danger staff-error"></span>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default create_user" <?php echo (isset($users[1]) && !empty($users[1])) ? 'disabled readonly' : ''; ?>>Submit</button>
    </div>
  </div>
</form>
 </div>
        </div>
     <div class="col-lg-4 col-md-4">
 <div class="Registration-form">
 
 <form class="form-horizontal">
  <div class="form-group">
    <label for="inputName" class="col-sm-2 control-label">Name</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name='name' placeholder="Name" value='<?php echo (isset($users[2]) && !empty($users[2])) ? $users[2]['name'] : ''; ?>' <?php echo (isset($users[2]) && !empty($users[2])) ? 'disabled readonly' : ''; ?>>
     <span class="error text-danger name-error"></span>
    </div>
  </div>
  <div class="form-group">
    <label for="inputMobile" class="col-sm-2 control-label">Mobile No.</label>
    <div class="col-sm-10">
      <input type="number" class="form-control" name='mobile' placeholder="Mobile No." value='<?php echo (isset($users[2]) && !empty($users[2])) ? $users[2]['mobile'] : ''; ?>' <?php echo (isset($users[2]) && !empty($users[2])) ? 'disabled readonly' : ''; ?>>
     <span class="error text-danger mobile-error"></span>
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
    <div class="col-sm-10">
      <input type="email" class="form-control" name='email' id="inputEmail3" placeholder="Email" value='<?php echo (isset($users[2]) && !empty($users[2])) ? $users[2]['email'] : ''; ?>' <?php echo (isset($users[2]) && !empty($users[2])) ? 'disabled readonly' : ''; ?>>
     <span class="error text-danger email-error"></span>
    </div>
  </div>
  <div class="form-group">
    <label for="Address" class="col-sm-2 control-label">Address</label>
    <div class="col-sm-10">
     <textarea class="form-control" rows="3" name='address' placeholder="Address" <?php echo (isset($users[2]) && !empty($users[2])) ? 'disabled readonly' : ''; ?>><?php echo (isset($users[2]) && !empty($users[2])) ? $users[2]['name'] : ''; ?></textarea>
     <span class="error text-danger address-error"></span>
    </div>
  </div>
  <div class="form-group">
    <label for="Staff Id" class="col-sm-2 control-label">Staff Id</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name='staff_id' placeholder="Staff Id" value="<?php echo $this->session->userdata('user_staff_id'); ?>" <?php echo (isset($users[2]) && !empty($users[2])) ? 'disabled readonly' : ''; ?> disabled readonly>
     <span class="error text-danger staff-error"></span>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default create_user" <?php echo (isset($users[2]) && !empty($users[2])) ? 'disabled readonly' : ''; ?>>Submit</button>
    </div>
  </div>
</form>
 </div>
        </div>
     <div class="col-lg-4 col-md-4">
 <div class="Registration-form print">

 <form class="form-horizontal">
  <div class="form-group">
    <label for="inputName" class="col-sm-2 control-label">Name</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name='name' placeholder="Name" value='<?php echo (isset($users[3]) && !empty($users[3])) ? $users[3]['name'] : ''; ?>' <?php echo (isset($users[3]) && !empty($users[3])) ? 'disabled readonly' : ''; ?>>
     <span class="error text-danger name-error"></span>
    </div>
  </div>
  <div class="form-group">
    <label for="inputMobile" class="col-sm-2 control-label">Mobile No.</label>
    <div class="col-sm-10">
      <input type="number" class="form-control" name='mobile' placeholder="Mobile No." value='<?php echo (isset($users[3]) && !empty($users[3])) ? $users[3]['mobile'] : ''; ?>' <?php echo (isset($users[3]) && !empty($users[3])) ? 'disabled readonly' : ''; ?>>
     <span class="error text-danger mobile-error"></span>
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
    <div class="col-sm-10">
      <input type="email" class="form-control" name='email' id="inputEmail3" placeholder="Email" value='<?php echo (isset($users[3]) && !empty($users[3])) ? $users[3]['email'] : ''; ?>' <?php echo (isset($users[3]) && !empty($users[3])) ? 'disabled readonly' : ''; ?>>
     <span class="error text-danger email-error"></span>
    </div>
  </div>
  <div class="form-group">
    <label for="Address" class="col-sm-2 control-label">Address</label>
    <div class="col-sm-10">
     <textarea class="form-control" rows="3" name='address' placeholder="Address" <?php echo (isset($users[3]) && !empty($users[3])) ? 'disabled readonly' : ''; ?>><?php echo (isset($users[3]) && !empty($users[3])) ? $users[3]['address'] : ''; ?></textarea>
     <span class="error text-danger address-error"></span>
    </div>
  </div>
  <div class="form-group">
    <label for="Staff Id" class="col-sm-2 control-label">Staff Id</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name='staff_id' placeholder="Staff Id" value='<?php echo $this->session->userdata('user_staff_id'); ?>' disabled readonly>
     <span class="error text-danger staff-error"></span>
    
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default create_user" <?php echo (isset($users[3]) && !empty($users[3])) ? 'disabled readonly' : ''; ?>>Submit</button>
    </div>
  </div>
</form>
 </div>
        </div>
        </div>
      </div>
     <?php if(count($users)==4): ?> 
        <div class="coupon-div">
        <div class="row">
        
        <div class="col-lg-12 col-md-12">
         <div class='coupon-print'>
            <p><b>Name: </b>
            <?php echo ucwords($this->session->userdata('user_name')); ?></p>
           
            <p><b>Staff id: </b>
            <?php echo $this->session->userdata('user_staff_id'); ?>
          </div>
        <button type="button" data-staffId='<?php echo $this->session->userdata('user_staff_id'); ?>' class="btn btn-primary btn-lg btn-block get_coupon"><a href="javascript:void(0);">Get A Coupan</a></button>
        </div>
        </div>
        </div>
      <?php endif; ?>

  <?php endif; ?>
</div>
	