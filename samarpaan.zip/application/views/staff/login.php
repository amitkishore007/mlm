   	
	<div class="container-fluid">
    <div class="row">
    <div class="col-lg-4 col-md-offset-4">
  <div class="Registration-form">
  <p class="alert alert-danger text-center error-msg">Email/password did not matched</p>
 
 <form class="form-horizontal" method="post">
  <div class="form-group">
    <label for="inputName" class="col-sm-6 control-label ">Staff id</label>
    <div class="col-sm-10">
      <input type="text" class="form-control email"  placeholder="Name">
    </div>
  </div>
  <div class="form-group">
    <label for="inputMobile" class="col-sm-3 control-label">Password</label>
    <div class="col-sm-10">
      <input type="Password" class="form-control password"  placeholder="Password">
      <span class="text-danger error"></span>
    </div>
  </div>
  
  
  
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
    <input type="hidden" name="action" value="<?php echo base_url('staffLogin/login'); ?>">
      <button type="submit" class="btn btn-default login-btn" > <a href="javascript:void(0);">Login</a></button>
      <div class="clearfix"></div>
    </div>
  </div>
</form>
    <p class="text-center">  <a href="<?php echo base_url('admin'); ?>">Admin login</a></p>
 </div>
        </div>
		 
		 
        </div>
    
    </div>
	