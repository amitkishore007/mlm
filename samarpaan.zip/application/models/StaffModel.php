<?php 
defined('BASEPATH') OR exit('No direct script access allowed');


/**
* 
*/
class StaffModel extends CI_Model
{
	
	
	public function create() {

		$info  = $this->input->post();

		$this->load->library('form_validation');

			$output = array('status'=>'false','name'=>'','phone'=>'','password'=>'','staff_id'=>'');
	

		if ($this->form_validation->run('staff_form_validation')==FALSE) {
			
			$this->form_validation->set_error_delimiters('', '');
		
			$output['name']     = form_error('name');
			$output['phone']   = form_error('mobile');
			$output['staff_id'] = form_error('staff_id');
			$output['password'] = form_error('password');
			

		} else {

			$info['password'] = md5($info['password']);
			

			$this->db->insert('staff',$info);

			if ($this->db->affected_rows()) {
					
				
				$output['status'] = "true";	
				

			}


		}

		return $output;
	}

	public function staffList() {

		$q = $this->db->order_by('created_at','desc')->get('staff');

		if ($q->num_rows()) {
			
			return $q->result();
		}

	}

	public function findStaff($id) {

		$q = $this->db->where(['id'=>$id])->get('staff');

		if ($q->num_rows()==1) {
		
			return $q->row();
		}
	}


	public function edit_staff() {


		$info  = $this->input->post();

		$this->load->library('form_validation');

			$output = array('status'=>'false','name'=>'','phone'=>'','staff_id'=>'');

			if ($this->form_validation->run('staff_edit_form_validation')==FALSE) {
				
				$this->form_validation->set_error_delimiters('', '');
				$output['name']     = form_error('name');
				$output['phone']    = form_error('mobile');
				$output['staff_id'] = form_error('staff_id');
			

			} else {


				$id = (int) addslashes(trim($this->input->post('id')));
				$data = array(

					'name'     =>$this->input->post('name'),
					'mobile'   =>$this->input->post('mobile'),
					'staff_id' =>$this->input->post('staff_id')
					);

				$q = $this->db->where(['id'=>$id])->get('staff');


				if ($q->num_rows()==1) {
					
					$this->db->where(['id'=>$id])->update('staff',$data);

					if ($this->db->affected_rows()>=0) {
							
						$output['status'] = 'success';
							

					}

				}

			}

			return $output;

	}


	public function delete() {

		$output = 'false';
		
		$id = (int) addslashes($this->input->post('id'));


		$q = $this->db->where(['id'=>$id])->get('staff');

		if ($q->num_rows()==1) {
			
			$this->db->where(['id'=>$id])->delete("staff");

			if ($this->db->affected_rows()==1) {
				
				$output = 'success';
			}
		}

		return $output;
	}


	public function create_user() {

		$info = $this->input->post();
		$this->load->library('form_validation');

			$output = array('status'=>'false','name'=>'','mobile'=>'','staff_id'=>'','email'=>'','address'=>'','total_reg'=>$this->getTotalReg());
	


		if ($this->form_validation->run('user_create_form_validation')==FALSE) {
			
			$this->form_validation->set_error_delimiters('', '');
		
			$output['name']     = form_error('name');
			$output['mobile']   = form_error('mobile');
			$output['staff_id'] = form_error('staff_id');
			$output['email'] 	= form_error('email');
			$output['address'] 	= form_error('address');
			

		} else {

			$staff_id = $info['staff_id'];
			
			$q = $this->db->where(['staff_id'=>$staff_id])->get('staff');


			if ($q->num_rows()==1) {
					
				$data = array(

					'name'=>htmlentities($info['name']),
					'email'=>htmlentities($info['email']),
					'mobile'=>htmlentities($info['mobile']),
					'address'=>htmlentities($info['address']),
					'staff_id'=>htmlentities($info['staff_id']),
					'parent_id'=>htmlentities($info['parent_id'])

				);	
				$this->db->insert('users',$data);

				if ($this->db->affected_rows()==1) {
					
					$output['status'] = 'success';
					$output['total_reg'] = $this->getTotalReg();
				}
			} 


		}

		return $output;

	}

	public function getTotalReg() {

		$q = $this->db->where(['staff_id'=>$this->session->userdata('user_staff_id')])->count_all_results('users');

		return $q;
	}

	public function get_all_reg_users() {

		$q = $this->db->where(['staff_id'=>$this->session->userdata('user_staff_id')])->order_by('created_at','desc')->get('users');

		if ($q->num_rows()) {
		
			return $q->result();
		}

	}

	public function get_user() {

		$phone = addslashes(trim($this->input->get('search')));

		$q = $this->db->like('mobile',$phone)->get('users');

		if ($q->num_rows()) {
			
			return $q->row();
		}

	}

	public function get_all_sub_users($user_id) {

		$total_registration = (int) $this->db->where(['parent_id'=>$user_id])->count_all_results('users');
		if ($total_registration) {
			
			$limit = ($total_registration % 3==0) ? 3 : ($total_registration % 3) ;

			$q = $this->db->where(['parent_id'=>$user_id])->order_by('created_at','DESC')->limit($limit)->get('users');

			if ($q->num_rows()) {
				
				return $q->result_array();
			}
		}

	}

	public function generate_coupon() {

		$user_id = (int) $this->input->post('user_id');
		$user1   = (int) $this->input->post('user1');
		$user2   = (int) $this->input->post('user2');
		$user3   = (int) $this->input->post('user3');
		$coupon  = $this->input->post('coupon');

		$output = 'error';
		
		$this->db->insert('coupons',[

			'user_id'=>$user_id,
			'user1'=>$user1,
			'user2'=>$user2,
			'user3'=>$user3,
			'coupon'=>$coupon

			]);

		if ($this->db->affected_rows()==1) {
			
				// $this->db->set('account_status',0)->where(['id'=>$user_id])->limit(1);

				// if ($this->db->affected_rows()==1) {
					
					$output = 'success';
				// }
		}

		return $output;

	}


	public function coupon_status($user,$user1,$user2,$user3) {

		$q = $this->db->where([

			'user_id'=>$user->id,
			'user1'=>$user1,
			'user2'=>$user2,
			'user3'=>$user3
			])->get('coupons');

		if ($q->num_rows()) {
				
				return true;
		}

	}


	public function activate_user() {

		$user_id = (int) $this->input->post('user_id');

		$this->db->set('account_status',1)->where(['id'=>$user_id])->update('users');

		$output = 'error';

		if ($this->db->affected_rows()==1) {
			
			$output = 'success';
		}

		return $output;

	}





}