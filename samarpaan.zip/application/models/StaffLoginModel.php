<?php 
defined('BASEPATH') OR exit('No direct script access allowed');



/**
* 
*/
class StaffLoginModel extends CI_Model
{
	

	public function login($table) {

		$info  = $this->input->post();

		$this->load->library('form_validation');

		$output = array();
		
		$output['status'] = "false";
		
		$output['error']    = "";
				

		if ($this->form_validation->run('staff_login_form_validation')==FALSE) {
				
			
			$output['error']    = form_error('email') . ' <br/>'.form_error('password');
			

		} else {

			$data = array(
				'password'=>md5($info['password']),
				'staff_id'=>$info['email'],
				'status'=>1
				);
			
			
			
			$result = $this->db->where($data)->get($table);
			
			if ($result->num_rows()) {
					
				$user  = $result->row();
				$data = array(

					'user_id'      => $user->id,
					'user_email'   => '',
					'user_name'   => $user->name,
					'user_staff_id'   => $user->staff_id,
					'user_type'	   => $user->user_type,	 
					'is_logged_in' => 1

					);

				$this->session->set_userdata($data);
				
				$output['status'] = "success";
			

			} else {
				
				$output['error']  = "Email/password did not matched !";
				
			}


		}

		return $output;

	}

}

